# AI Trading Signal Terminal for XAU/USD & BTC/USD

## Overview

This is a professional AI-powered trading terminal that generates and displays real-time trading signals for Gold (XAU/USD) and Bitcoin (BTC/USD) markets. The application provides traders with precise entry, stop-loss, and take-profit levels based on technical analysis and AI-driven market insights. The system analyzes multiple technical indicators (RSI, MACD, EMA, Bollinger Bands, Stochastic) and presents signals in a professional trading terminal interface inspired by TradingView and Bloomberg Terminal design patterns.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18 with TypeScript**: Type-safe component development with modern React patterns
- **Vite**: Fast build tool and development server with HMR (Hot Module Replacement)
- **Wouter**: Lightweight client-side routing library (alternative to React Router)
- **TanStack Query (React Query)**: Server state management with automatic caching, background refetching, and WebSocket data synchronization

**UI Framework & Styling**
- **Shadcn/ui**: Component library built on Radix UI primitives, providing accessible, customizable components
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens for trading-specific colors
- **Design Philosophy**: Trading terminal approach prioritizing information density, clarity, and instant data comprehension over aesthetic appeal
- **Typography**: Monospace fonts (JetBrains Mono/Roboto Mono) for numerical data; Inter/IBM Plex Sans for general text
- **Color System**: Custom trading colors for buy/sell signals, profit/loss indicators, and market states
- **Theme Support**: Dark mode by default with light mode option, theme persistence via localStorage

**State Management Strategy**
- **Server State**: React Query handles all API data fetching, caching, and real-time updates
- **WebSocket State**: Custom `useWebSocket` hook manages live price feeds and signal updates
- **Local State**: React Context API for theme management; component-level state for UI interactions
- **Data Flow**: WebSocket messages update React Query cache, triggering automatic component re-renders

**Layout System**
- **Desktop**: Two-column layout (60/40 split) - left side for charts, right side for signals and indicators
- **Tablet/Mobile**: Stacked single-column layout with collapsible sections
- **Responsive Grid**: Tailwind breakpoints with information hierarchy optimized for different screen sizes

### Backend Architecture

**Server Framework**
- **Express.js**: HTTP server handling REST API endpoints
- **Node.js with ES Modules**: Modern JavaScript runtime using `type: "module"` in package.json
- **TypeScript**: Type safety across backend services and API routes
- **WebSocket Server (ws)**: Real-time bidirectional communication for live price feeds and signal updates

**API Structure**
- **REST Endpoints**:
  - `/api/price/:market` - Current price data for XAU/USD or BTC/USD
  - `/api/candles/:market` - Historical candlestick data with configurable interval and limit
  - `/api/indicators/:market` - Technical indicator calculations (RSI, MACD, EMA, etc.)
  - `/api/signals` - Trading signals history
  - `/api/analysis/:market` - Multi-timeframe analysis data
- **WebSocket Endpoint**: `/ws` - Real-time streaming of prices, signals, and indicator updates

**Service Layer Architecture**
- **Market Data Service** (`marketDataService`): Fetches real-time and historical market data from external APIs (Binance for BTC/XAU prices)
- **Technical Indicators Service** (`indicatorsService`): Calculates RSI, MACD, EMA, Bollinger Bands, and Stochastic indicators using `technicalindicators` library
- **AI Signal Generator** (`aiSignalGenerator`): Uses OpenAI API to analyze market data and generate trading signals with entry/SL/TP levels
- **WebSocket Service** (`TradingWebSocketServer`): Manages WebSocket connections, broadcasts real-time updates to connected clients

**AI Signal Generation**
- **OpenAI Integration**: GPT model analyzes technical indicators, price movements, and market conditions
- **Signal Criteria**: Generates BUY/SELL signals only when confidence exceeds 65%
- **Risk Management**: Automatic calculation of 1:1, 1:2, and 1:3 risk-reward ratios for TP levels
- **Reasoning**: AI provides 2-3 sentence explanations for each signal decision

**Data Storage**
- **In-Memory Storage**: `MemStorage` class provides temporary storage for users and signals during development
- **Database Ready**: Drizzle ORM configured for PostgreSQL with schema definitions in `shared/schema.ts`
- **Schema Design**: 
  - Users table with authentication fields
  - Signals table structure defined in TypeScript interfaces (PriceData, Signal, TPLevel)
  - Support for signal status tracking (Active, Hit TP1/TP2/TP3, Stopped Out, Pending)

### External Dependencies

**Third-Party APIs**
- **Binance API** (`https://api.binance.com/api/v3`): Real-time cryptocurrency price data for BTC/USD (BTCUSDT) and XAU/USD (PAXGUSDT proxy)
- **Twelve Data API** (configured but optional): Alternative market data provider for forex and crypto data
- **OpenAI API**: GPT model for AI-powered trading signal generation and market analysis

**Database**
- **PostgreSQL**: Configured via Drizzle ORM with Neon serverless driver (`@neondatabase/serverless`)
- **Database URL**: Environment variable `DATABASE_URL` required for production deployment
- **Migration Management**: Drizzle Kit handles schema migrations in `./migrations` directory

**Key Libraries**
- **Technical Analysis**: `technicalindicators` - RSI, MACD, EMA, Bollinger Bands, Stochastic calculations
- **Charting**: `recharts` - Candlestick chart visualization with custom OHLC rendering
- **Date Handling**: `date-fns` - Date formatting and manipulation for timestamps
- **Form Validation**: `zod` with `@hookform/resolvers` for type-safe form schemas
- **WebSocket**: `ws` library for server-side WebSocket implementation

**Development Tools**
- **Replit Plugins**: Cartographer (code navigation), dev banner, runtime error overlay
- **Build Tools**: esbuild for server bundling, Vite for client bundling
- **Type Checking**: TypeScript compiler with strict mode enabled

**Environment Variables Required**
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API key for signal generation
- `TWELVE_DATA_API_KEY`: (Optional) Twelve Data API key for market data
- `NODE_ENV`: Environment mode (development/production)