import { TimeframeSelector } from "../TimeframeSelector";

export default function TimeframeSelectorExample() {
  return (
    <div className="p-6">
      <TimeframeSelector />
    </div>
  );
}
