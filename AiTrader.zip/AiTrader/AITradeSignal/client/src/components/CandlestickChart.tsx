import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { ComposedChart, XAxis, YAxis, Tooltip, ResponsiveContainer, Bar, Cell } from "recharts";
import { format } from "date-fns";
import type { CandleData } from "@shared/schema";

interface CandlestickChartProps {
  market: "XAU/USD" | "BTC/USD";
  timeframe: string;
}

export function CandlestickChart({ market, timeframe }: CandlestickChartProps) {
  const marketParam = market.toLowerCase().replace("/", "");

  const { data: candles = [], isLoading, error } = useQuery<CandleData[]>({
    queryKey: ["candles", marketParam, timeframe],
    queryFn: async () => {
      const response = await fetch(`/api/candles/${marketParam}?interval=${timeframe}&limit=50`);
      if (!response.ok) throw new Error("Failed to fetch candle data");
      return response.json();
    },
    refetchInterval: 30000,
    staleTime: 15000,
  });

  if (isLoading) {
    return (
      <Card className="p-6 h-96 flex items-center justify-center">
        <div className="text-muted-foreground">Loading chart data...</div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 h-96 flex items-center justify-center">
        <div className="text-destructive">Failed to load chart data</div>
      </Card>
    );
  }

  const chartData = candles.map((candle) => ({
    ...candle,
    time: format(new Date(candle.timestamp), "HH:mm"),
    formattedTime: format(new Date(candle.timestamp), "MMM dd HH:mm"),
  }));

  const yDomain = candles.length > 0 
    ? [
        Math.min(...candles.map(c => c.low)) * 0.999,
        Math.max(...candles.map(c => c.high)) * 1.001
      ]
    : [0, 100];

  const chartHeight = 320;
  const chartMarginTop = 10;
  const chartMarginBottom = 20;
  const actualChartHeight = chartHeight - chartMarginTop - chartMarginBottom;

  const createCandlestickShape = (domain: number[], height: number) => (props: any) => {
    const { x, width, payload } = props;
    
    if (!payload || width === 0) return null;
    
    const { open, close, high, low } = payload;
    const isGreen = close >= open;
    const color = isGreen ? "#10b981" : "#ef4444";
    
    const [minPrice, maxPrice] = domain;
    const priceRange = maxPrice - minPrice;
    
    const yScale = (price: number) => {
      return chartMarginTop + ((maxPrice - price) / priceRange) * height;
    };
    
    const candleWidth = Math.max(width * 0.6, 3);
    const centerX = x + width / 2;
    
    const highY = yScale(high);
    const lowY = yScale(low);
    const openY = yScale(open);
    const closeY = yScale(close);
    
    const bodyY = Math.min(openY, closeY);
    const bodyHeight = Math.abs(closeY - openY);
    
    return (
      <g>
        <line
          x1={centerX}
          y1={highY}
          x2={centerX}
          y2={lowY}
          stroke={color}
          strokeWidth={1}
        />
        <rect
          x={centerX - candleWidth / 2}
          y={bodyY}
          width={candleWidth}
          height={Math.max(bodyHeight, 1)}
          fill={color}
          stroke={color}
          strokeWidth={1}
        />
      </g>
    );
  };

  return (
    <Card className="p-4">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">{market} Chart</h3>
        <p className="text-sm text-muted-foreground">Timeframe: {timeframe}</p>
      </div>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: chartMarginTop, right: 30, bottom: chartMarginBottom, left: 60 }}>
            <XAxis
              dataKey="time"
              stroke="#888888"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
              minTickGap={30}
            />
            <YAxis
              domain={yDomain}
              stroke="#888888"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => value.toFixed(market === "BTC/USD" ? 0 : 2)}
              width={70}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload?.[0]) return null;
                const data = payload[0].payload;
                const isGreen = data.close >= data.open;
                const change = data.close - data.open;
                const changePercent = ((change / data.open) * 100).toFixed(2);
                
                return (
                  <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
                    <p className="text-xs text-muted-foreground mb-2">{data.formattedTime}</p>
                    <div className="space-y-1 text-xs font-mono">
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Open:</span>
                        <span>{data.open.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">High:</span>
                        <span className="text-green-500">{data.high.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Low:</span>
                        <span className="text-red-500">{data.low.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Close:</span>
                        <span className={isGreen ? "text-green-500" : "text-red-500"}>
                          {data.close.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between gap-4 pt-1 border-t border-border">
                        <span className="text-muted-foreground">Change:</span>
                        <span className={isGreen ? "text-green-500" : "text-red-500"}>
                          {isGreen ? "+" : ""}{changePercent}%
                        </span>
                      </div>
                    </div>
                  </div>
                );
              }}
            />
            <Bar
              dataKey="close"
              shape={createCandlestickShape(yDomain, actualChartHeight)}
              isAnimationActive={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
